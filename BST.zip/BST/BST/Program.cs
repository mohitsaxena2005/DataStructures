﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design.Serialization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;


// Inorder traversal always sorts the BST: Left Subtree, node , right subtree
namespace BST
{
    class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            Node root = null;
            


            int[] arr = new int[] {10,6,8,12,65,7,99,23,43,5,3,2,1};
            int[] outputFromIntArr = new int[arr.Length];

            BTree bst = new BTree(arr.Length);

            for (int i = 0; i < arr.Length; i++)
            {
                root = bst.InsertNode(root, arr[i]);
            }
            //bst.Traverse(root);

            bst.InorderTraverse(root);
            Node newRoot = bst.BalanceTree(0, arr.Length - 1);
            Console.WriteLine("***************");

            Console.WriteLine(bst.GetHeightOfTree(newRoot));
            //bst.DeleteNode(newRoot, 65);
            
            bst.LevelOrderTraversalOrBreadthFirstTravesal(newRoot);


        }
    }

    public class Node
    {
        public Node left;
        public Node right;
        public int val;

        public Node(int value)
        {
            val = value;
        }

    }

    public class BTree
    {
        public ArrayList sortedArrayFromInorder;

        public BTree(int lengthOfArr)
        {
            sortedArrayFromInorder = new ArrayList();
        }

        public Node InsertNode(Node root, int val)
        {
            if (root == null)
            {
                root = new Node(val);
                
            }

            if (root.val > val)
            {
                root.left = InsertNode(root.left, val);
            }

            if (root.val < val)
            {
                root.right = InsertNode(root.right, val);
            }

            return root;
        }

        public Node DeleteNode(Node root, int val)
        {
            // 3 possible scenarios 
            // 1. Deleted Node is leaf
            // 2. Delete node has only one child
            // 3. Deleted node has two child

            if (root == null)
                return root;

            if (val > root.val)
                DeleteNode(root.right, val);
            else if (val < root.val)
                    DeleteNode(root.left, val);
            else
            {
                // node with only one child or leaf node
                if (root.left == null)
                    return root.right;
                else if (root.right == null)
                    return root.left;


                // Node with 2 children: Get the smallest in the right subtree as all in the left wil automatically be smaller than the nodes in right side

                root.val = minValue(root.right);

                // Delete the smallest value and put it place of Node that is deleted
                root.right = DeleteNode(root.right, root.val);
            }

            return root;

        }

        int minValue(Node root)
        {
            int minv = root.val;
            while (root.left != null)
            {
                minv = root.left.val;
                root = root.left;
            }
            return minv;
        }


        public Node BalanceTree(int start , int end)
        {
            if (start > end)
                return null;

            int mid = (start + end)/2;
            Node node = new Node(Convert.ToInt32(sortedArrayFromInorder[mid]));
            node.left = BalanceTree(start, mid - 1);
            node.right = BalanceTree(mid + 1, end);

            return node;

        }

        
        public void InorderTraverse(Node root)
        {
            int i = 0;
            if (root == null)
                return;
            
            InorderTraverse(root.left);
            
            Console.WriteLine(root.val);
            sortedArrayFromInorder.Add(root.val);
            InorderTraverse(root.right);
        }

        public void PreorderTraverse(Node root)
        {
            if (root == null)
                return;

            Console.WriteLine(root.val);
            InorderTraverse(root.left);
            InorderTraverse(root.right);
        }

        public void PostorderTraverse(Node root)
        {
            if (root == null)
                return;

            
            InorderTraverse(root.left);
            InorderTraverse(root.right);
            Console.WriteLine(root.val);
        }

        public void LevelOrderTraversalOrBreadthFirstTravesal(Node root)
        {
            int height = GetHeightOfTree(root);
            for (int i = 1; i <= height; i++)
            {
                printLevelOrder(root, i);
            }
        }

        public void printLevelOrder(Node root, int level)
        {
            if (root == null)
                return;
            if(level ==1)
                Console.WriteLine(root.val);
            else if (level > 1)
            {
                printLevelOrder(root.left, level-1);
                printLevelOrder(root.right, level - 1);
            }
                   
        }

        public int GetHeightOfTree(Node root)
        {
            if (root == null)
                return 0;
            int lHeight = GetHeightOfTree(root.left);
            int rHeight = GetHeightOfTree(root.right);
            if (lHeight > rHeight)
                return lHeight + 1;
            else
            {
                return rHeight+1;
            }
        }

        public void Traverse(Node root)
        {
            if (root == null)
                return;
            Console.WriteLine(root.val);
            Traverse(root.left);
            Traverse(root.right);
        }

        public void PrintBoundaryNodesInTree()
        {
            
        }

        public void PrintTopViewOfTree()
        {
            
        }

        public void PrintTreeVertically()
        {
            
        }
    }
}
